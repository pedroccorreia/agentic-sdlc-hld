# Parking Lot — open items & questions

> **Sources:** `zip arc1.pdf` (document page 1 — setup/environment + stages) and
> `zip  architecture.pdf` (document pages 2–5 — artifacts, agents, control
> plane, open action items).
>
> **Status key:** ✅ resolved · 🔴 blocking · 🟠 needed before build · 🟡 needed before scale · ⚪ nice to have
>
> Nothing here is invented. Where an answer is *inferred* rather than written
> down, it says so.

---

## ✅ Closed by the late-arriving page 1

Three items that were open after the first four pages are now answered outright.

| ID | Item | Resolution |
|---|---|---|
| **PL-01** | Phase (4) never named | ✅ **Phase (4) is `Review`.** Written explicitly on page 1: *"reviews the Build Report and provides a score"*, producing **Score agent**, **Feedback register**, and **Approve / Not approve + Reason**. Previously an inference — now attested. |
| **PL-15** | Scan page 3 labelled "Page 4" — missing page? | ✅ **Explained, and nothing is missing.** With page 1 inserted at the front the set reads: p1 = setup & stages, p2 = artifacts, p3 = negotiation & agents, **p4 = documentation & control plane** — exactly the label the author wrote. The sequence is complete. |
| **PL-24** | Registry technology unstated | ✅ **Cloud SQL** for *scoring runs*, **Cloud Storage** for *artefacts storage*. |

**Partially advanced:**

| ID | Item | What moved |
|---|---|---|
| **PL-16** | No evaluation model | Q.5 states the *principle* — **"score should be user feedback + data driven (pass tests)"** — and stage 4 names its three outputs. The **shape** is now visible; the **computation** still is not. Downgraded from "undefined" to "unspecified". |
| **PL-07** | Four basics to lock in | **Toolchain now named:** Antigravity, Antigravity CLI, VS Code, gcloud, Terraform. **CI/CD path partly answered:** push/pull against a GitHub repo maintained by the engineering/architecture team, with GCP deploying infrastructure and running tests. **Still open:** the programming language itself, and the documentation repo (which is Q.6). |
| **PL-03** | Personas & sub-processes per phase | Two human gates are now explicit — *PRD GO / NO-GO* between stages 1 and 2, and *Approve / Not approve + Reason* at stage 4 — plus a persona at stage 5. Still no full persona × phase matrix. |
| **PL-19** | No security / identity model | Q.2 raises the **centralized kill switch** as an explicit open question, which is one component of it. Authn/authz, agent credentials and approval authentication remain unaddressed. |

---

## ✅ Closed or advanced by the working corpus

Cross-referencing the transcribed architecture against the other documents
already in the project folder — `zip_persona_catalogue.md`, `zip_prd.md`,
`zip_fde_scope_notes.md`, `zip_engagement_plan.md`,
`zip_internal_agentic_factory.md`.

**Closed outright:**

| ID | Item | Answer in the corpus |
|---|---|---|
| **PL-03** | Personas & sub-processes per phase | ✅ A full catalogue: **six families, ~28 persona definitions, ~45 running instances** across five LMS domains, mapped to the same stage numbering as the whiteboard. |
| **PL-33** | "Shadow gate testing" undefined | ✅ Merged code **mirrors live production traffic against the incumbent system at scale, with zero customer impact** until full verification. |
| **PL-27 / Q.2** | Centralized kill switch | ✅ Specified as an **always-on cross-cutting control** maintained across all sandbox execution environments. Needs building, not deciding. |
| **PL-29 / Q.4** | Unit test in disposable sandboxes | ✅ Yes — the Antigravity fleet builds in **disposable Cloud Run sandboxes**. |
| **PL-32 / Q.7** | Building w/ Claude | ✅ Position stated: frontier models are **consumed as inference and routed across Gemini and Claude**, while **tools, skills and evals remain owned assets**. A defensible architectural stance; the commercial conversation is separate. |

**Advanced:**

| ID | Item | What moved |
|---|---|---|
| **PL-16** | Evaluation model | An **Eval Engineer** persona owns the scoring harness and escaped-defect analysis; an **Autonomy Rung Governor** governs promotion/demotion on evidence per task class; evals are named as owned assets. **The scoring function itself is still undefined.** |
| **PL-19** | Security / identity | The registry checks the agent's **certificate**; the control plane issues **least-privilege audit records**; audit records are **immutable in Cloud Logging**. Authorisation scope — what an agent may touch through the MCP surface — is still undefined. |
| **PL-20** | Failure / rollback | The **shadow gate** is the safety mechanism. But see **PL-37** — it has two missing sub-steps without which it degrades into noise. |
| **PL-25** | Human review bottleneck | **Autonomy rungs** are the intended answer: task classes get promoted as confidence is proven, so review load falls over time rather than scaling linearly with throughput. |
| **PL-24** | Registry storage | Already closed by page 1 (Cloud SQL + Storage); the corpus adds that **telemetry routes to Google Cloud Observability**. |

**New items raised by reading the two views together:**

| ID | Item | Status | Detail |
|---|---|---|---|
| **PL-37** | **The shadow gate has two missing sub-steps** | 🔴 | **Side-effect suppression** — shadow traffic runs against a system that moves money; without explicit suppression, mirrored requests can fire real disbursements, repayment collections, customer notifications and credit-bureau reporting. **State re-baselining** — once shadow state diverges from legacy by a single rounding difference, every later comparison inherits the error, *"the divergence queue becomes noise within weeks and the gate stops carrying meaning."* This is the last line of defence before customer impact, and it fails silently. |
| **PL-38** | **Personas are not modelled as registry entities** | 🟠 | The catalogue states personas are **versioned, evaluated assets that drift after model upgrades** — which is why a Persona Steward exists to re-baseline them. But nothing in the transcribed architecture models a persona as a registry entity with a version, rating and evaluation history, the way agents are. Add to the ER model (PL-02). |
| **PL-39** | **The two views are drifting apart** | 🟠 | The whiteboard is the *artifact and control* view; the corpus is the *persona and process* view. Neither is complete alone and they are diverging — **which is precisely the documentation-drift problem the architecture's own closed loop is designed to prevent.** The programme is exhibiting the problem it is built to solve. |
| **PL-40** | **Q.3 got harder, not easier** | 🟠 | Run-level control of a Generate run — pause, scope, budget, concurrency limits — is absent from **both** the whiteboard and the corpus. With a fleet building in parallel sandboxes against a metered inference bill, this is the gap with the most direct cost exposure. |

---

## A. Raised by the source documents

| ID | Item | Status | Why it matters | What would close it |
|---|---|---|---|---|
| **PL-02** | **DER for Registry** — a Data Entity Relationship model | 🔴 | Metadata is defined for six artifacts plus the agent record, but never the *relationships* between them. Everything downstream depends on it. | A reviewed ER model. A **first draft** is in `diagrams/06-registry-entities.mmd` — inference, needs confirmation. Now easier: the stores are known (Cloud SQL / Storage). |
| **PL-03** | **Personas & sub-processes per phase** | 🟠 | Determines who acts at each gate. Two gates now known. | A persona × phase matrix. Check `zip_persona_catalogue.md` in the parent folder first. |
| **PL-04** | **Documentation upkeep — non-existent** | 🟠 | The problem statement that the two documentation loops answer. See also Q.6. | Agreement on the loop design, plus an owner. |
| **PL-06** | **Agents that can build archetypes** — dependent on evaluation | 🟡 | Blocked behind the evaluation model (**PL-16**). | Define evaluation, then revisit. |
| **PL-07** | **Basics to lock in:** programming language · monitoring · CI/CD path · documentation repo | 🟠 | Was 🔴. Monitoring settled (Cloud Logging/Monitoring); toolchain and CI/CD substantially answered by page 1. **Programming language and documentation repo still open.** | A short platform-decisions ADR. |
| **PL-08** | **Dynamic allocation of agents** — stretch goal | ⚪ | Deliberately deferred. Deterministic routing is v1. | Revisit once ratings hold real data. |
| **PL-09** | **Should evaluation scenarios be built alongside the PRD?** | 🔴 | The PRD already carries `UNIT TEST STRATEGY`; the question is whether *evaluation* sits beside *testing*. Sharpened by Q.4 (disposable sandboxes) and Q.5. | A decision on where evaluation scenarios live and who owns them. |
| **PL-05** | **Agent cardinality "to be defined"** | 🟠 | One agent per task? Per task type? Per stack component? Drives registry size and routing. The stage-3 fan-out tree implies hierarchy but not cardinality. | A cardinality rule. |
| **PL-10** | **"Deterministic" agent selection asserted but not specified** | 🟠 | The only stated input is `Use when` — free text, which is not deterministic. The "taxi dispatcher" analogy on page 1 clarifies *intent* but not *mechanism*. | Define the matching algorithm and its inputs. |

---

## B. Numbered open questions from page 1 (Q.1 – Q.7)

The author's own numbered questions, carried across verbatim.

| ID | Q | Question | Status | Note |
|---|---|---|---|---|
| **PL-26** | **Q.1** | **Spec format — `.md`?** | 🟠 | Applies to the reviewed PRD entering Dispatch. Page 2 lists `txt / md / doc / pdf` for the BRD, so a house format decision is pending. Cheap to close, and it unblocks tooling. |
| **PL-27** | **Q.2** | **Centralized kill switch** | 🟠 | *How to do it centrally.* The console on page 4 has per-agent `kill`; this asks for a fleet-wide stop. Part of the broader security gap (PL-19). |
| **PL-28** | **Q.3** | **How to control a Generate run** | 🟠 | Run-level control: pause, scope, budget, concurrency limits. Nothing in the set addresses it. |
| **PL-29** | **Q.4** | **Unit test in disposable sandboxes** | 🟠 | Isolation model for parallel agent execution. Has real cost and security implications. |
| **PL-30** | **Q.5** | **Score should be user feedback + data driven (pass tests)** | 🔴 | The principle behind the evaluation model. Pairs directly with **PL-16** — treat them together. |
| **PL-31** | **Q.6** | **Where is their documentation** | 🟠 | Blocks the *upstream* documentation loop, which is what makes the PRD good. Also the unanswered half of PL-07's "documentation repo". |
| **PL-32** | **Q.7** | **Building w/ Claude** | 🟠 | Names a third-party model vendor. **Flagging as commercial/strategic, not technical** — worth handling deliberately before this material is used in a Google-facing conversation. |

---

## C. Transcription ambiguities

| ID | Page | Reading | Issue |
|---|---|---|---|
| **PL-11** | p2 | PRD document icon labelled **`SPEC`** | Glyph ambiguous. Low impact. |
| **PL-12** | p5 | **`DER`** for Registry | Read as *Data Entity Relationship*. Not expanded anywhere. |
| **PL-13** | p3 | Dashed **Final Report ⇠⇢ Negotiation File** | Endpoint and direction both hard to trace on the scan. |
| **PL-14** | p3 | Tech listed as **`GKE \| DATA \| Agents`** | Page 1's *"might be a GKE or Data Agent"* **largely confirms this reading** — `DATA` is an agent category, not a platform. Downgraded to near-resolved. |
| **PL-33** | p1 | **"shadow gate testing"** at Ship & Observe | Phrase is legible but the concept isn't defined anywhere. Is this canary/shadow traffic? A named internal gate? |
| **PL-34** | p1 | **Q.2 "kill switch / devices?"** | The second word after "kill switch" is uncertain. |

---

## D. Gaps visible only across the whole set

| ID | Gap | Status | Detail |
|---|---|---|---|
| **PL-16** | **Evaluation model unspecified** | 🔴 | Still the largest gap, though the shape is now visible. Known: score comes from *user feedback + data-driven pass-tests* (Q.5); stage 4 produces **Score agent**, **Feedback register**, **Approve/Not approve + Reason**; scoring runs persist to **Cloud SQL**. Unknown: **how it is computed, normalised, weighted between the two halves, and what acts on it.** |
| **PL-17** | **"LMS" never expanded or scoped** | 🟠 | The anchor of the whole effort, never described in five pages. |
| **PL-18** | **`SCORE` vs `Rating`** | 🟠 | Build Report has `SCORE`; the agent record has `Rating`; stage 4 says "score agent". **Page 1 makes it likelier these are the same mechanism**, but it isn't stated. A key edge in the ER model. |
| **PL-19** | **No security / identity model** | 🟠 | Who may kill an agent, what credentials agents hold, how `approve` is authenticated. Q.2 covers one slice. Sharpened by the MCP surface — **Jira and Slack MCP servers mean agents reach outside the build environment.** |
| **PL-20** | **No failure / rollback story** | 🟠 | All flows are happy-path. "Shadow gate testing" hints at a safety gate but isn't defined. |
| **PL-21** | **Negotiation File has no resolution lifecycle** | 🟡 | No status, owner, or link to the artifact *version* the feedback was raised against. Page 1's "Feedback register" is the same thing seen from the process side. |
| **PL-22** | **Two `review cycles` shapes differ** | 🟡 | PRD: `[FEEDBACK, REVIEW]`. Build Report: `[FEEDBACK, Actions]`. Deliberate or drift? |
| **PL-23** | **No artifact versioning** | 🟡 | Every artifact has a creation date, none a version — despite review cycles and re-approval. |
| **PL-25** | **Human review is the unmodelled bottleneck** | 🟡 | Now clearer, and worse: **three** human touchpoints are explicit (GO/NO-GO at 1→2, approve at 4, persona at 5) on top of human-curated BRDs. The design scales agents, not reviewers. |
| **PL-35** | **MCP integration surface is unscoped** | 🟠 | Jira MCP, Slack, and Custom MCP give agents broad reach. **Resolution:** Decouple tool packaging from authorization via **Agent Plugins 1.0.0**. Declare tool interfaces and transports in `mcp.json`; let GKE Control Plane dynamically inject short-lived, least-privilege Workload Identity OAuth tokens and enforce container network egress boundaries. |
| **PL-36** | **"Skills Agent = Zip SDLC Principles" is undefined** | 🟠 | The mechanism by which Zip's house rules reach every agent. **Resolution:** Adopt the open, vendor-neutral **Agent Plugins 1.0.0** standard. Formalize house rules, TDD test authoring rules, and linting into versioned plugins (`zip-sdlc-governance-plugin` + domain plugins), locked cryptographically in [`skills-lock.json`](../skills-lock.json). |
| **PL-43** | **Skills Catalog, Dual-Layer Sourcing (Google vs. Zip) & Dual-Runtime Sandboxing** | 🟢 | **Resolved via Google Skills Ecosystem & Agent Platform Sandboxing.** Created the 56-skill Master Catalog (`data/skills_catalog.json` & [`SKILLS_CATALOG.md`](SKILLS_CATALOG.md)) tracking provider (32 Google from `google/skills`, 24 Zip proprietary), resource status (33 Ready, 23 Need to Build), runtime execution substrate, and 44 Phase 1 MVP critical path skills. Architected a Dual-Runtime execution strategy: Tier A (Agent Platform zero-trust managed `code_execution` for AST/TDD/linting) and Tier B (Cloud Run BYOD custom Docker containers for legacy C# decompilation and multi-service mock harnesses). Fully integrated into the Factory Explorer UI. |

---

## Suggested triage for the next Zip session

**Decide these three first:**

1. **PL-37 — the shadow gate's two missing sub-steps.** Promoted to the top after
   reading the corpus. Side-effect suppression and state re-baselining are the
   difference between a working last line of defence and one that produces green
   dashboards while meaning nothing. It fails *silently*, on a system that moves
   money. Cheapest to fix now, most expensive to discover late.
2. **PL-16 + Q.5 (PL-30) — the evaluation model.** Still the highest-value
   structural item. The principle is stated and the surrounding roles now exist
   (Eval Engineer, Autonomy Rung Governor), but the scoring function does not.
   Accelerate via Google **Agents CLI** evaluation plugins persisting to Cloud SQL.
3. **PL-36 — the Skills Agent via Agent Plugins 1.0.0.** Formalize how Zip's SDLC principles
   reach every agent by standardizing on the vendor-neutral **Agent Plugins 1.0.0** format
   (Google, Amazon, Microsoft, OpenAI, Cursor, Vercel), locked via `skills-lock.json`.

**Then:** PL-40/Q.3 (run-level control — the biggest cost exposure, and absent
from both views) · PL-19 + PL-35 (authorisation scope across the MCP surface;
resolved by keeping credentials in GKE Workload Identity, not `mcp.json`) · PL-02 + PL-38 (ER model,
now needing personas as first-class entities) · PL-26/Q.1 (spec format — cheap,
unblocks tooling) · PL-31/Q.6 (where documentation lives) · PL-05 (cardinality).

**Raise as a process point, not a technical one:** **PL-39** — the artifact view
and the persona view are drifting apart, which is the exact failure the
architecture's closed documentation loop exists to prevent.

**No longer needs deciding:** Q.2 (kill switch), Q.4 (disposable sandboxes) and
Q.7 (Gemini/Claude routing via Agent Plugins 1.0.0 + Vertex AI) are all answered
in the working corpus — they need **building**, not deciding.
