import json, re, os

# 1. Load updated skills from skills_catalog.json
with open("architecture-unpack/data/skills_catalog.json") as f:
    skills = json.load(f)

# Attach double diamond markdown content from .agents/skills/
id_to_dir = {
    "loan_amortization_calculator": "loan-amortization-calculator",
    "interest_accrual_validator": "interest-accrual-validator",
    "delinquency_waterfall_checker": "delinquency-waterfall-checker",
    "merchant_fee_settler": "merchant-fee-settler",
    "credit_decisioning_scorer": "credit-decisioning-scorer",
    "double_entry_balance_checker": "double-entry-balance-checker",
    "zero_cent_drift_prover": "zero-cent-drift-prover",
    "bitemporal_schema_auditor": "bitemporal-schema-auditor",
    "currency_precision_validator": "currency-precision-validator",
    "idempotent_backfill_designer": "idempotent-backfill-designer",
    "reg_z_tila_checker": "reg-z-tila-checker",
    "reg_b_ecoa_auditor": "reg-b-ecoa-auditor",
    "fdcpa_disclosure_scanner": "fdcpa-disclosure-scanner",
    "pci_dss_tokenization_verifier": "pci-dss-tokenization-verifier",
    "statutory_clause_mapper": "statutory-clause-mapper",
    "zip_coding_standards_linter": "zip-coding-standards-linter",
    "isolated_tdd_test_generator": "isolated-tdd-test-generator",
    "ast_conformance_differ": "ast-conformance-differ",
    "side_effect_suppression_filter": "side-effect-suppression-filter",
    "shadow_divergence_classifier": "shadow-divergence-classifier",
    "adr_extractor": "adr-extractor",
    "autonomy_rung_evaluator": "autonomy-rung-evaluator",
    "token_unit_cost_calculator": "token-unit-cost-calculator",
}

for s in skills:
    sid = s["id"]
    if sid in id_to_dir:
        path = f".agents/skills/{id_to_dir[sid]}/SKILL.md"
        if os.path.exists(path):
            with open(path) as sf:
                s["double_diamond_spec"] = sf.read()
                s["authored_via"] = "Double Diamond (Discover, Define, Develop, Deliver)"
                s["status_label"] = "Ready (Authored via Double Diamond)"
    elif sid == "double_diamond_design":
        path = ".agents/skills/double-diamond-design/SKILL.md"
        with open(path) as sf:
            s["double_diamond_spec"] = sf.read()
            s["status_label"] = "Ready (Core Methodological Asset)"

# 2. Parse PGSP Personas from MASTER_PERSONAS_PGSP.md
with open("architecture-unpack/MASTER_PERSONAS_PGSP.md") as f:
    master_pgsp = f.read()

# Map persona ID like 'A1', 'A2', ... to detailed content
persona_map = {}
chunks = re.split(r"### Persona ([A-F][0-9]):\s*", master_pgsp)
for i in range(1, len(chunks), 2):
    p_code = chunks[i].strip()
    raw_body = chunks[i+1].strip()
    
    # Extract Double Diamond synthesis and PGSP blocks
    dd_match = re.search(r"#### Double Diamond Synthesis\n(.*?)(?=#### Modern Agent Specification|\Z)", raw_body, re.DOTALL)
    dd_text = dd_match.group(1).strip() if dd_match else ""
    
    p_profile = re.search(r"- \*\*P — Persona Profile:\*\*\n(.*?)(?=- \*\*G — Goals|\Z)", raw_body, re.DOTALL)
    g_goals = re.search(r"- \*\*G — Goals & Invariants:\*\*\n(.*?)(?=- \*\*S — Skills|\Z)", raw_body, re.DOTALL)
    s_skills = re.search(r"- \*\*S — Skills & Substrates:\*\*\n(.*?)(?=- \*\*P — Protocols|\Z)", raw_body, re.DOTALL)
    p_protocols = re.search(r"- \*\*P — Protocols & Governance:\*\*\n(.*?)(?=\n---|###|\Z)", raw_body, re.DOTALL)
    
    persona_map[p_code] = {
        "raw": raw_body,
        "double_diamond": dd_text,
        "p_profile": p_profile.group(1).strip() if p_profile else "",
        "g_goals": g_goals.group(1).strip() if g_goals else "",
        "s_skills": s_skills.group(1).strip() if s_skills else "",
        "p_protocols": p_protocols.group(1).strip() if p_protocols else ""
    }

print(f"Parsed {len(persona_map)} personas from MASTER_PERSONAS_PGSP.md")

# 3. Read HTML
html_path = "architecture-unpack/presentation/factory-explorer.html"
with open(html_path) as f:
    html = f.read()

# Update stats pills
html = html.replace(
    '<div class="stat-pill" style="background:#17022C;border:1px solid #00D4FF"><div class="val" style="color:#00D4FF">33</div><div class="lbl">Ready (Have Resource)</div></div>\n      <div class="stat-pill" style="background:#17022C;border:1px solid #FF3366"><div class="val" style="color:#FF3366">23</div><div class="lbl">To Build (Need Resource)</div></div>',
    '<div class="stat-pill" style="background:#17022C;border:1px solid #00D4FF"><div class="val" style="color:#00D4FF">56</div><div class="lbl">Ready (100% Complete)</div></div>\n      <div class="stat-pill" style="background:#17022C;border:1px solid #BEF202"><div class="val" style="color:#BEF202">23</div><div class="lbl">Authored (Double Diamond)</div></div>'
)

# Update filter button pills
html = html.replace(
    '<button class="btn" onclick="filterSkills(\'status\', \'have_resource\', this)" style="border-color:#00D4FF;color:#00D4FF">Ready (Have Resource) (33)</button>\n        <button class="btn" onclick="filterSkills(\'status\', \'need_to_build\', this)" style="border-color:#FF3366;color:#FF3366">To Build (23)</button>',
    '<button class="btn" onclick="filterSkills(\'status\', \'have_resource\', this)" style="border-color:#00D4FF;color:#00D4FF">Ready (Have Resource) (56)</button>\n        <button class="btn" onclick="filterSkills(\'authored\', \'dd\', this)" style="border-color:#BEF202;color:#BEF202">💎 Authored via Double Diamond (23)</button>'
)

# Update skillsCatalogData in HTML
start_marker = "const skillsCatalogData = ["
end_marker = "];\n\nlet activeSkillFilter = { type: 'provider', val: 'all' };"

s_idx = html.find(start_marker)
e_idx = html.find(end_marker)

if s_idx != -1 and e_idx != -1:
    skills_json_str = json.dumps(skills, indent=2)
    html = html[:s_idx] + f"const skillsCatalogData = {skills_json_str};\nconst pgspPersonasData = {json.dumps(persona_map, indent=2)};" + html[e_idx + 2:]
    print("Injected updated skillsCatalogData and pgspPersonasData into HTML.")
else:
    print("ERROR: Could not find markers for skillsCatalogData in HTML")

# 4. Save updated HTML
with open(html_path, "w") as f:
    f.write(html)

print(f"Updated {html_path} successfully. File size: {os.path.getsize(html_path)} bytes.")
