import json, os, re

with open("architecture-unpack/presentation/factory-explorer.html") as f:
    html = f.read()

print("HTML length:", len(html))
print("Contains skillsCatalogData:", "const skillsCatalogData = [" in html)
print("Contains personasFullCatalog:", "const personasFullCatalog = [" in html)
