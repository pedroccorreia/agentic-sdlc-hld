import json, os, re

# 1. Load 56 skills from skills_catalog.json
with open("architecture-unpack/data/skills_catalog.json") as f:
    skills = json.load(f)

print(f"Loaded {len(skills)} skills from catalog.")

# 2. For each skill, attach Double Diamond content if available
id_to_dir = {
    "loan_amortization_calculator": "loan-amortization-calculator",
    "interest_accrual_validator": "interest-accrual-validator",
    "delinquency_waterfall_checker": "delinquency-waterfall-checker",
    "merchant_fee_settler": "merchant-fee-settler",
    "credit_decisioning_scorer": "credit-decisioning-scorer",
    "double_entry_balance_checker": "double-entry-balance-checker",
    "zero_cent_drift_prover": "zero-cent-drift-prover",
    "bitemporal_schema_auditor": "bitemporal-schema-auditor",
    "currency_precision_validator": "currency-precision-validator",
    "idempotent_backfill_designer": "idempotent-backfill-designer",
    "reg_z_tila_checker": "reg-z-tila-checker",
    "reg_b_ecoa_auditor": "reg-b-ecoa-auditor",
    "fdcpa_disclosure_scanner": "fdcpa-disclosure-scanner",
    "pci_dss_tokenization_verifier": "pci-dss-tokenization-verifier",
    "statutory_clause_mapper": "statutory-clause-mapper",
    "zip_coding_standards_linter": "zip-coding-standards-linter",
    "isolated_tdd_test_generator": "isolated-tdd-test-generator",
    "ast_conformance_differ": "ast-conformance-differ",
    "side_effect_suppression_filter": "side-effect-suppression-filter",
    "shadow_divergence_classifier": "shadow-divergence-classifier",
    "adr_extractor": "adr-extractor",
    "autonomy_rung_evaluator": "autonomy-rung-evaluator",
    "token_unit_cost_calculator": "token-unit-cost-calculator",
}

for s in skills:
    sid = s["id"]
    if sid in id_to_dir:
        skill_file = f".agents/skills/{id_to_dir[sid]}/SKILL.md"
        if os.path.exists(skill_file):
            with open(skill_file) as sf:
                text = sf.read()
            s["double_diamond_content"] = text
            s["has_double_diamond"] = True
            s["authored_via"] = "Double Diamond Design (Discover, Define, Develop, Deliver)"
    elif sid == "double_diamond_design":
        skill_file = ".agents/skills/double-diamond-design/SKILL.md"
        with open(skill_file) as sf:
            s["double_diamond_content"] = sf.read()
        s["has_double_diamond"] = True

print(f"Attached Double Diamond content to {sum(1 for s in skills if s.get('has_double_diamond'))} skills.")

# 3. Parse Personas PGSP from MASTER_PERSONAS_PGSP.md
with open("architecture-unpack/MASTER_PERSONAS_PGSP.md") as f:
    master_pgsp = f.read()

# Extract sections per persona
persona_sections = {}
persona_chunks = re.split(r"### Persona ([A-F][0-9]):\s*", master_pgsp)
# persona_chunks[0] is header, then pairs of (ID, content)
for i in range(1, len(persona_chunks), 2):
    p_id = persona_chunks[i].strip()
    p_content = persona_chunks[i+1]
    persona_sections[p_id] = p_content.strip()

print(f"Extracted PGSP content for {len(persona_sections)} personas: {list(persona_sections.keys())}")
