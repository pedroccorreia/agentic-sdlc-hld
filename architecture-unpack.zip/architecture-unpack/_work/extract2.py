import re, os

SRC = ("/Users/pcorreia/ge_spark_workspace/session_workspaces/"
       "session_e3560eb3-5291-4a1a-865e-fcdd79aa4f30/.shared/uploads/zip arc1.pdf")
OUT = ("/Users/pcorreia/Documents/Customers/Zip/Zip - Agentic Factory/"
       "architecture-unpack/_work/pages2")
os.makedirs(OUT, exist_ok=True)

d = open(SRC, "rb").read()
print("bytes", len(d))
print("pageobjs", len(re.findall(rb"/Type\s*/Page[^s]", d)))
print("counts", re.findall(rb"/Count\s+(\d+)", d)[:10])
print("filters", set(re.findall(rb"/Filter\s*/(\w+)", d)))

count, pos = 0, 0
while True:
    s = d.find(b"stream", pos)
    if s == -1:
        break
    i = s + 6
    if d[i:i+2] == b"\r\n":
        i += 2
    elif d[i:i+1] in (b"\n", b"\r"):
        i += 1
    e = d.find(b"endstream", i)
    if e == -1:
        break
    blob = d[i:e].rstrip(b"\r\n")
    if blob[:2] == b"\xff\xd8" and blob[-2:] == b"\xff\xd9":
        count += 1
        p = os.path.join(OUT, "arc1_%02d.jpg" % count)
        open(p, "wb").write(blob)
        print("wrote", p, len(blob))
    pos = e + 9
print("extracted", count)
