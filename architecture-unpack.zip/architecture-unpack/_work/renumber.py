"""Insert a 'Setup and environment' section as section 2 of ARCHITECTURE.md and
renumber the existing sections 2..9 -> 3..10. Also fixes the intra-doc
references to renumbered sections if any exist."""
import re

P = ("/Users/pcorreia/Documents/Customers/Zip/Zip - Agentic Factory/"
     "architecture-unpack/ARCHITECTURE.md")
t = open(P).read()

# 1. renumber 9 -> 10, 8 -> 9, ... 2 -> 3 (descending so we don't collide)
titles = {
    2: "The delivery pipeline",
    3: "The six artifacts",
    4: "Artifact dependencies",
    5: "Agents and the registry",
    6: "Control plane, monitoring and logging",
    7: "Documentation as a closed loop",
    8: "Assessment \u2014 what's strong, what's missing",
    9: "Where to go next",
}
for n in sorted(titles, reverse=True):
    old = "## %d. %s" % (n, titles[n])
    new = "## %d. %s" % (n + 1, titles[n])
    assert old in t, "missing heading: " + old
    t = t.replace(old, new)

SECTION = """## 2. Setup and environment

*Source: document page 1. This material appears on no other page of the set.*

### The repository is the hub

```mermaid
graph LR
    ENG["Engineering / Architecture team"] -->|push| GH["GITHUB REPO"]
    GH -->|pull| DEV["Dev 1 &middot; Dev 2 &middot; Dev 3"]
    GH --- SK["Skills Agent<br/>= Zip SDLC Principles"]
    classDef a fill:#FFF4E5,stroke:#F29900,stroke-width:2px;
    classDef b fill:#EAF2FF,stroke:#1A73E8,stroke-width:2px;
    class ENG,DEV a;
    class GH,SK b;
```

The engineering/architecture team maintains the repo and pushes to it;
developers pull. Attached to the repo is a **Skills Agent**, annotated
**"= Zip SDLC Principles"**.

> **This is the most under-specified important thing in the architecture.** The
> Skills Agent is the mechanism by which Zip's house engineering rules reach
> every agent in the fleet \u2014 effectively the governance backbone \u2014 and it
> appears exactly once, as a callout, with no elaboration on how principles are
> encoded, versioned, tested or enforced. See [PL-36](PARKING_LOT.md).

### Toolchain

| Tool | |
|---|---|
| **Antigravity** | **Antigravity CLI** |
| **VS Code** | **gcloud** |
| **Terraform** | |

### Google Cloud

**GCP** carries two stated responsibilities \u2014 **deploy infrastructure** and
**run tests** \u2014 with persistence split by purpose:

| Store | Holds |
|---|---|
| **Cloud SQL** | scoring runs |
| **Cloud Storage** | artefacts storage |

That answers where the registry and artifacts physically live, which was
previously unstated ([PL-24](PARKING_LOT.md), now closed).

### Integration surface \u2014 MCP

Three integration points are named: a **Jira MCP Server**, **Slack**, and a
**Custom MCP**.

> **Worth pausing on.** An agent that can write to Jira and post to Slack has a
> materially larger blast radius than one confined to a repo. Combined with the
> absent identity model and the not-yet-built central kill switch, this is one
> combined risk rather than three separate ones \u2014
> [PL-35](PARKING_LOT.md), [PL-19](PARKING_LOT.md), Q.2.

Editable source: [`diagrams/07-setup-environment.mmd`](diagrams/07-setup-environment.mmd)

---

"""

anchor = "## 3. The delivery pipeline"
assert anchor in t
t = t.replace(anchor, SECTION + anchor, 1)

open(P, "w").write(t)
print("done")
for m in re.finditer(r"^## .*$", t, re.M):
    print(" ", m.group(0))
