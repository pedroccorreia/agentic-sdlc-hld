#!/usr/bin/env python3
"""Generate an HTML file that shows a cropped, magnified region of a page scan.

Usage: crop.py <pageNN.jpg> <x> <y> <w> <h> <scale> <out.html>
Coordinates are in source-image pixels.
"""
import sys, os

img, x, y, w, h, scale, out = sys.argv[1:8]
x, y, w, h, scale = int(x), int(y), int(w), int(h), float(scale)

# native size lookup table (filled by caller via env or hardcoded below)
SIZES = {
    "page01.jpg": (2314, 3316),
    "page02.jpg": (2163, 3061),
    "page03.jpg": (2054, 2897),
    "page04.jpg": (2093, 2961),
}
base = os.path.basename(img)
W, H = SIZES[base]

cw, ch = int(w * scale), int(h * scale)

html = f"""<!doctype html>
<html><head><meta charset="utf-8"><style>
  html,body {{ margin:0; padding:0; background:#fff; }}
  .crop {{
    width:{cw}px; height:{ch}px;
    background-image:url("file://{os.path.abspath(img)}");
    background-size:{int(W*scale)}px {int(H*scale)}px;
    background-position:{-int(x*scale)}px {-int(y*scale)}px;
    background-repeat:no-repeat;
    image-rendering:auto;
    filter: contrast(1.25) saturate(1.1);
  }}
</style></head><body><div class="crop"></div></body></html>"""

open(out, "w").write(html)
print(f"{out} -> {cw}x{ch}")
