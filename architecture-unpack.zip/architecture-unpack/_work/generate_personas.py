import os

output_file = "architecture-unpack/MASTER_PERSONAS_PGSP.md"

header = """# Zip Agentic Factory — Master Agent Persona Catalog
**Double Diamond Syntheses & Modern Agent Specifications (P-G-S-P)**
**Project Catalyst · Agent Factory / LMS Rebuild**
**Date:** September 2, 2026
**Target Architecture:** Google Cloud Platform & Zip Sovereign Lending Assets
**Reference Standard:** [Agent Plugins 1.0.0](https://agent-plugins.org/) · [Double Diamond Design Process](.agents/skills/double-diamond-design/SKILL.md)

---

## 1. Executive Summary & Design Principles

The Zip Agentic Factory treats agent personas as the **actual capital product** of the transformation. Generated code is ephemeral, disposable, and regenerable; the **persona library coupled with the high-definition specification catalog** represents the compounding assets that ensure cycle $n+1$ costs less than cycle $n$.

### The Three Axioms of Persona Architecture:
1. **Principle 2.1: Author and Judge are Never the Same Persona:**
   Every generative persona operates in an adversarial pair with an opposing judge holding an independent objective function. If an agent writes both code and tests, bugs are encoded as expected behavior and coverage metrics become vanity theater.
2. **Principle 2.2: Personas are Versioned, Evaluated Assets, Not Prompt Snippets:**
   Every persona possesses a named human owner, semver tracking, an isolated evaluation suite measuring drift across model upgrades, and promotion criteria across autonomy rungs.
3. **Principle 2.3: Not Everything is a Persona:**
   Deterministic control-plane functions (certificate verification, token budget bounding, network allowlists) are enforced via platform policy engines (Stage 2 Dispatcher), not probabilistic LLM reasoning.

```
       THE MODERN AGENT SPECIFICATION TEMPLATE (P-G-S-P)
┌────────────────────────────────────────────────────────────────────────┐
│ P — PERSONA PROFILE                                                    │
│ • Identity, Role, Phase, Autonomy Rung, Adversarial Counterpart        │
│ • Mental Model, Domain Archetype, Voice & Tone, Core System Prompt     │
├────────────────────────────────────────────────────────────────────────┤
│ G — GOALS & INVARIANTS                                                 │
│ • Primary Mission, Mathematical/Domain Invariants Enforced             │
│ • Definition of Done / Acceptance Criteria, Anti-Goals (Prohibitions)  │
├────────────────────────────────────────────────────────────────────────┤
│ S — SKILLS & SUBSTRATES                                                │
│ • Mapped Skills (56-Skill Catalog), Runtime (Tier A vs Tier B)         │
│ • Permitted Tools, MCP Capabilities, Tool Execution Constraints        │
├────────────────────────────────────────────────────────────────────────┤
│ P — PROTOCOLS & GOVERNANCE                                             │
│ • Adversarial Handshake, Upstream Inputs, Downstream Deliverables      │
│ • Quality Gate Criteria, Side-Effect Suppression, Safety Boundaries    │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Master Personas Roster & Lifecycle Matrix

| # | ID | Persona Name | Family | Phase | Autonomy | Adversarial Counterpart | Primary Operational Focus |
|---|---|---|---|:---:|:---:|---|---|
| 1 | `A1` | Product Manager | Intent & Scope | 1 | L2 | `A6 Spec Adversary` | Value proposition, user ROI, feature prioritization, MVP boundary |
| 2 | `A2` | Domain SME (×5 Domains) | Intent & Scope | 1 | L2 | `A5 Requirements Architect` | Lending correctness across Decisioning, Issuing, Repayments, Customer, Merchant |
| 3 | `A3` | Regulatory & Compliance Analyst | Intent & Scope | 1 | L2 | `A1 Product Manager` | Statutory regulatory basis: Reg Z, Reg B, FDCPA, GLBA, UDAAP, SCRA, PCI DSS |
| 4 | `A4` | UX/UI Designer | Intent & Scope | 1 | L2 | `A5 Requirements Architect` | Usability, WCAG 2.1 AA accessibility, distressed borrower journey clarity |
| 5 | `A5` | Requirements Architect *(Author)* | Intent & Scope | 1 | L2 | `A6 Spec Adversary` | Unambiguous, testable, high-definition specification synthesis |
| 6 | `A6` | Spec Adversary *(Judge)* | Intent & Scope | 1 | L2 | `A5 Requirements Architect` | Ambiguity hunting, contradiction detection, unstated assumption challenge |
| 7 | `B1` | Software Architect | Architecture | 1-2 | L3 | `B2 Data Architect` | System scalability, microservice boundaries, design pattern enforcement |
| 8 | `B2` | Data Architect | Architecture | 1-2 | L2 | `B1 Software Architect` | Ledger integrity, double-entry schemas, bitemporal tables, no-float math |
| 9 | `B3` | Integration Engineer | Architecture | 1-2 | L3 | `C1 Implementation Engineer` | Contract boundaries, idempotency, stubbing out-of-bounds legacy dependencies |
| 10 | `B4` | Identity & Access Engineer | Architecture | 1-2 | L2 | `D2 Security Red Team` | AuthN/AuthZ, Workload Identity Federation, least privilege, zero-trust |
| 11 | `C1` | Implementation Engineer | Build | 3 | L3 | `D1 Spec Conformance Judge` | Deterministic code generation to strict spec; zero unrequested behavior |
| 12 | `C2` | Test Engineer *(Isolated)* | Build | 3 | L3 | `C1 Implementation Engineer` | Zero-code-access spec-derived conformance and property-based test suites |
| 13 | `C3` | Migration & Backfill Engineer | Build | 3 | L3 | `B2 Data Architect` | Restartable, idempotent historical ETL migration with cent-for-cent parity |
| 14 | `D1` | Spec Conformance Judge | Review | 4 | L2 | `C1 Implementation Engineer` | AST diffing verifying "nothing more, nothing less" against approved PRD |
| 15 | `D2` | Security Engineer / Red Team | Review | 4 | L2 | `C1 Implementation Engineer` | OWASP Top 10, secrets leaks, privilege escalation, threat modeling |
| 16 | `D3` | QA / Adversarial Tester | Verify | 5 | L3 | `C1 Implementation Engineer` | Boundary stress, leap years, odd intervals, currency edge cases, concurrency |
| 17 | `D4` | Regulatory Conformance Verifier | Verify | 5 | L2 | `A3 Compliance Analyst` | Auditor-legible evidence pack generation against Stage 1 regulatory map |
| 18 | `D5` | SRE / Resilience Engineer | Verify | 5 | L2 | `B1 Software Architect` | Latency SLOs, 10x load stress, Chaos Mesh injection, 15-minute rollback drill |
| 19 | `D6` | Reconciliation Analyst | Ship & Observe | 6 | L2 | `A2 Domain SME` | Shadow gate dual-run triage: 4-class taxonomy, zero unexplained divergences |
| 20 | `E1` | Observability Engineer | Sustain | 6 | L3 | `D5 SRE / Resilience` | Telemetry coverage, PromQL alerting, structured JSON logging, 3am diagnosability |
| 21 | `E2` | Documentation Curator | Sustain | 7 | L3 | `A5 Requirements Architect` | Spec deduplication, ADR harvesting, compounding knowledge asset library |
| 22 | `E3` | Release & Change Manager | Sustain | 6 | L2 | `Executive Humans` | Cutover sequencing, deployment governance, rollback rehearsal sign-off |
| 23 | `F1` | Persona Steward | Factory Governance | 7 | L2 | `F2 Eval Engineer` | Prompt versioning, model upgrade drift diagnosis, persona catalog re-baselining |
| 24 | `F2` | Eval Engineer | Factory Governance | 7 | L3 | `C2 Test Engineer` | Benchmark scoring harness, escaped defect capture, eval regression suites |
| 25 | `F3` | Autonomy Rung Governor | Factory Governance | 2 | L2 | `Chris Nelms (CISO)` | Task promotion/demotion evidence evaluation, L1-L4 boundary control |
| 26 | `F4` | Token Economics Analyst | Factory Governance | 7 | L3 | `Eric Blassberg (Delivery)` | Unit cost per spec, token attribution, cache ROI, declining cost proof |

---
"""

with open(output_file, "w") as f:
    f.write(header)

print(f"Written header to {output_file}")
