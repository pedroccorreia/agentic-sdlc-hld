import re

with open("architecture-unpack/presentation/factory-explorer.html") as f:
    text = f.read()

# Extract personas array
match = re.search(r"const personasFullCatalog = \[(.*?)\];\s*// ====", text, re.DOTALL)
if match:
    block = match.group(1)
    ids = re.findall(r'id:\s*"([^"]+)"', block)
    names = re.findall(r'name:\s*"([^"]+)"', block)
    print(f"Found {len(ids)} personas in factory-explorer.html:")
    for i, (pid, name) in enumerate(zip(ids, names)):
        print(f" {i+1}. {pid}: {name}")
else:
    print("Could not locate personasFullCatalog block")
