import re

with open("architecture-unpack/presentation/factory-explorer.html") as f:
    html = f.read()

# 1. Insert Home Announcement Banner right after hero banner
hero_end = '    </div>\n  </div>\n\n  <!-- DUAL ENTRY POINT CARDS -->'
home_announcement = """    </div>
  </div>

  <!-- ANNOUNCEMENT: Double Diamond Skills & Modern Agent Specs (P-G-S-P) -->
  <div style="background:linear-gradient(90deg, #240046 0%, #3C096C 50%, #17002C 100%);border:1px solid var(--zip-lime);border-radius:12px;padding:1.1rem 1.5rem;margin-bottom:1.8rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1.2rem;box-shadow:0 0 25px rgba(190,242,2,0.18)">
    <div style="display:flex;align-items:center;gap:1rem">
      <span style="font-size:2.2rem;line-height:1">💎</span>
      <div>
        <div style="display:flex;align-items:center;gap:.6rem;flex-wrap:wrap">
          <span style="color:#FFF;font-weight:900;font-size:1.1rem;letter-spacing:-0.02em">NEW UPDATE: Double Diamond Skills &amp; Modern Agent Specifications (P-G-S-P)</span>
          <span class="badge-mini" style="background:#2E4C00;color:var(--zip-lime);border:1px solid var(--zip-lime);font-size:.68rem;font-weight:800">56/56 READY (100%)</span>
          <span class="badge-mini" style="background:#1B033A;color:#00D4FF;border:1px solid #00D4FF;font-size:.68rem;font-weight:800">26 PERSONAS CERTIFIED</span>
        </div>
        <p style="color:#D8CCE8;font-size:.84rem;margin-top:.35rem;line-height:1.45">All 23 unbuilt lending domain, banking ledger, regulatory, and SDLC governance skills are now fully authored via the 4-phase Double Diamond design process, and all 26 factory personas are specified using the Modern Agent Specification Template (P-G-S-P).</p>
      </div>
    </div>
    <div style="display:flex;gap:.6rem;flex-wrap:wrap">
      <button class="btn btn-primary" onclick="switchSection('personas', 'skills')" style="font-weight:700">🧩 Explore 56 Skills Catalog ↗</button>
      <button class="btn" onclick="switchSection('personas')" style="background:#1E043B;border-color:#BEF202;color:#FFF;font-weight:700">👥 Explore 26 Personas (P-G-S-P) ↗</button>
    </div>
  </div>

  <!-- DUAL ENTRY POINT CARDS -->"""

if hero_end in html:
    html = html.replace(hero_end, home_announcement)
    print("Inserted Home Announcement Banner.")
else:
    print("Could not find hero_end insertion target.")

# 2. Add JavaScript functions for Skill Detail Modal and Persona Tabs
js_functions = """
// ==============================================================================
// SKILL DETAIL MODAL & DOUBLE DIAMOND VIEWER
// ==============================================================================
let currentInspectedSkill = null;

function openSkillDetailModal(sId) {
  const s = skillsCatalogData.find(item => item.id === sId);
  if (!s) return;
  currentInspectedSkill = s;

  document.getElementById('modalSkillName').textContent = s.name;
  document.getElementById('modalSkillId').textContent = s.id;
  document.getElementById('modalSkillCategory').textContent = s.category.toUpperCase();
  document.getElementById('modalSkillProvider').textContent = s.provider.toUpperCase() + ' PROVIDED';
  document.getElementById('modalSkillStatus').textContent = (s.status_label || (s.resource_status === 'have_resource' ? 'READY (HAVE RESOURCE)' : 'TO BUILD')).toUpperCase();
  document.getElementById('modalSkillRuntime').textContent = (s.execution_runtime || 'UNIVERSAL / BOTH').toUpperCase();
  document.getElementById('modalSkillDesc').textContent = s.description;

  // MVP badge
  const mvpContainer = document.getElementById('modalSkillMVPBadge');
  mvpContainer.innerHTML = s.is_mvp 
    ? '<span class="badge-mini" style="background:#2E4C00;color:var(--zip-lime);border:1px solid var(--zip-lime);font-weight:800;font-size:.72rem">⭐ PHASE 1 MVP CRITICAL</span>'
    : '<span class="badge-mini" style="background:#140026;color:#A89BC2;border:1px solid #36155F;font-size:.72rem">PHASE 2+ EXTENSION</span>';

  // Acting personas
  document.getElementById('modalSkillPersonas').innerHTML = `<b>Acting Personas:</b> ` + s.acting_personas.map(ap => `<span class="badge-mini" style="background:#16022B;color:#DDD2EC;border:1px solid #431674;font-size:.68rem;cursor:pointer" onclick="closeSkillDetailModal();openPersonaByString('${ap.replace(/'/g, "\\'")}')">${ap} ↗</span>`).join(' ');

  // Location / file ref
  document.getElementById('modalSkillLocation').innerHTML = s.local_ref 
    ? `<b>Source:</b> <code style="color:var(--zip-lime)">${s.local_ref}</code>` 
    : `<b>Reference:</b> <a href="${s.resource_ref}" target="_blank" style="color:#00D4FF">${s.resource_ref}</a>`;

  // Parse Double Diamond sections
  const rawSpec = s.double_diamond_spec || '';
  document.getElementById('skillRawContent').textContent = rawSpec || 'Specification source code is mounted in the Google Skills ecosystem (~/.gemini/config/skills/' + s.id + ').';

  const ddContainer = document.getElementById('skillDDContainer');
  const invContainer = document.getElementById('skillInvariantsContainer');
  const codeContainer = document.getElementById('skillCodeContainer');

  if (rawSpec) {
    // Extract Double Diamond phases
    const p1 = extractBetween(rawSpec, "### Phase 1: Discover", "### Phase 2: Define") || "Discovery notes on problem space, legacy Azure LMS discrepancies, and regulatory citations.";
    const p2 = extractBetween(rawSpec, "### Phase 2: Define", "### Phase 3: Develop") || "Mathematical invariants, schemas, and contract boundaries.";
    const p3 = extractBetween(rawSpec, "### Phase 3: Develop", "### Phase 4: Deliver") || "Algorithmic logic, pseudo-code, and runtime execution strategy.";
    const p4 = extractBetween(rawSpec, "### Phase 4: Deliver", "## Operational Guide") || "Executable specification deliverable and exit criteria.";

    ddContainer.innerHTML = `
      <div style="background:#120026;padding:.9rem 1.1rem;border-radius:8px;border-left:3px solid #00D4FF">
        <h4 style="color:#00D4FF;margin:0 0 .3rem 0;font-size:.9rem">Phase 1: Discover (Divergent)</h4>
        <div style="color:#E0D5F2;line-height:1.5">${formatMarkdownSimple(p1)}</div>
      </div>
      <div style="background:#120026;padding:.9rem 1.1rem;border-radius:8px;border-left:3px solid #BEF202">
        <h4 style="color:#BEF202;margin:0 0 .3rem 0;font-size:.9rem">Phase 2: Define (Convergent)</h4>
        <div style="color:#E0D5F2;line-height:1.5">${formatMarkdownSimple(p2)}</div>
      </div>
      <div style="background:#120026;padding:.9rem 1.1rem;border-radius:8px;border-left:3px solid #A855F7">
        <h4 style="color:#A855F7;margin:0 0 .3rem 0;font-size:.9rem">Phase 3: Develop (Divergent)</h4>
        <div style="color:#E0D5F2;line-height:1.5">${formatMarkdownSimple(p3)}</div>
      </div>
      <div style="background:#120026;padding:.9rem 1.1rem;border-radius:8px;border-left:3px solid #FF3366">
        <h4 style="color:#FF3366;margin:0 0 .3rem 0;font-size:.9rem">Phase 4: Deliver (Convergent)</h4>
        <div style="color:#E0D5F2;line-height:1.5">${formatMarkdownSimple(p4)}</div>
      </div>
    `;

    invContainer.innerHTML = `
      <div style="background:#0F001E;padding:1rem;border-radius:8px;border:1px solid #3B166E">
        <h4 style="color:var(--zip-lime);margin-top:0">Mathematical &amp; Ledger Invariants</h4>
        <div style="line-height:1.6">${formatMarkdownSimple(p2)}</div>
      </div>
    `;

    const codeSnippet = extractCodeBlock(rawSpec) || "# No Python/Go snippet included. See raw SKILL.md.";
    codeContainer.innerHTML = `
      <div style="background:#090014;border:1px solid #2B0C4F;border-radius:8px;padding:1rem">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem">
          <span style="color:var(--zip-lime);font-size:.75rem;font-weight:700">CODE / SCHEMA / TEST VECTOR</span>
          <span style="color:#A89BC2;font-size:.7rem">Fixed-Point minor units (Cents)</span>
        </div>
        <pre style="color:#BEF202;font-family:var(--font-mono);font-size:.78rem;overflow-x:auto;line-height:1.42;margin:0">${escapeHtml(codeSnippet)}</pre>
      </div>
    `;
  } else {
    ddContainer.innerHTML = `<div style="background:#120026;padding:1rem;border-radius:8px;color:#A89BC2">This Google Cloud Platform skill is mounted from the official Google skills ecosystem. Detailed documentation is available at <a href="${s.resource_ref}" target="_blank" style="color:#00D4FF">${s.resource_ref}</a>.</div>`;
    invContainer.innerHTML = `<div style="color:#A89BC2">Refer to upstream documentation for metric/query specifications.</div>`;
    codeContainer.innerHTML = `<div style="color:#A89BC2">Refer to upstream documentation.</div>`;
  }

  switchSkillModalTab('dd');
  document.getElementById('skillDetailModal').classList.add('open');
}

function closeSkillDetailModal() {
  document.getElementById('skillDetailModal').classList.remove('open');
}

function switchSkillModalTab(tab) {
  const tabs = ['dd', 'invariants', 'code', 'raw'];
  tabs.forEach(t => {
    const btn = document.getElementById('tabBtnSkill' + t.charAt(0).toUpperCase() + t.slice(1));
    const content = document.getElementById('skillTabContent' + t.charAt(0).toUpperCase() + t.slice(1));
    if (btn) btn.className = (t === tab) ? 'btn btn-primary' : 'btn';
    if (content) content.style.display = (t === tab) ? 'block' : 'none';
  });
}

function switchPersonaTab(tab) {
  const tabs = ['overview', 'profile', 'goals', 'skills', 'protocols', 'dd'];
  tabs.forEach(t => {
    const btn = document.getElementById('btnPersTab' + t.charAt(0).toUpperCase() + t.slice(1));
    const content = document.getElementById('persTab' + t.charAt(0).toUpperCase() + t.slice(1));
    if (btn) btn.className = (t === tab) ? 'btn btn-primary' : 'btn';
    if (content) content.style.display = (t === tab) ? 'block' : 'none';
  });
}

// Helper utilities for markdown rendering in modals
function extractBetween(text, startPattern, endPattern) {
  const s = text.indexOf(startPattern);
  if (s === -1) return '';
  const e = text.indexOf(endPattern, s + startPattern.length);
  if (e === -1) return text.substring(s);
  return text.substring(s + startPattern.length, e).trim();
}

function extractCodeBlock(text) {
  const m = text.match(/```[a-z]*\\n([\\s\\S]*?)```/);
  return m ? m[1] : '';
}

function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function formatMarkdownSimple(md) {
  let s = escapeHtml(md);
  // Bold
  s = s.replace(/\\*\\*(.*?)\\*\\*/g, '<b style="color:#FFF">$1</b>');
  // Italic
  s = s.replace(/\\*(.*?)\\*/g, '<i>$1</i>');
  // Inline code
  s = s.replace(/`([^`]+)`/g, '<code style="color:var(--zip-lime);background:#0B0017;padding:1px 4px;border-radius:3px">$1</code>');
  // Linebreaks
  s = s.replace(/\\n/g, '<br/>');
  return s;
}
"""

# Replace openPersonaModal with enhanced version that binds PGSP data
old_open_persona = "function openPersonaModal(pId) {"
new_open_persona = """function openPersonaModal(pId) {
  const p = personasFullCatalog.find(item => item.id === pId);
  if (!p) return;
  currentInspectedPersona = p;

  document.getElementById('modalPersFamily').textContent = p.family.toUpperCase();
  document.getElementById('modalPersRole').textContent = p.role.toUpperCase();
  document.getElementById('modalPersMVP').style.display = p.isMVP ? 'inline-block' : 'none';
  document.getElementById('modalPersName').textContent = p.name;
  document.getElementById('modalPersFocus').textContent = `Primary Focus: ${p.focus}`;
  document.getElementById('modalPersOverview').textContent = p.overview;
  document.getElementById('modalPersAdversary').innerHTML = `
    <span class="entity-pill-persona" style="margin:0;cursor:pointer" onclick="closePersonaModal();jumpToPersona('${p.adversary.replace(/'/g, "\\'")}')">
      ⚔️ ${p.adversary} <span class="entity-arrow">↗</span>
    </span>
  `;
  document.getElementById('modalPersPhases').innerHTML = p.phases.map(num => `
    <button class="btn" style="padding:.2rem .6rem;font-size:.75rem;margin:2px;display:inline-flex;align-items:center;gap:.3rem" onclick="closePersonaModal();navigateToPhase(${num - 1})">
      ⚡ Jump to Phase ${num} (${factoryPhases[num-1]?.name || ''}) ↗
    </button>
  `).join(' ');
  document.getElementById('modalPersPrompt').textContent = `"${p.prompt}"`;

  const skillsContainer = document.getElementById('modalPersSkillsList');
  skillsContainer.innerHTML = p.skills.map(s => `
    <div style="background:#120026;border:1px solid #36155F;border-radius:6px;padding:.55rem .8rem;display:flex;justify-content:space-between;align-items:center;gap:.5rem">
      <div style="display:flex;flex-direction:column;gap:.2rem">
        <code style="color:var(--zip-lime);font-weight:700;font-size:.82rem">${s.name}</code>
        <div style="color:#D8CCE8;font-size:.78rem;line-height:1.4">${s.desc}</div>
      </div>
      <button class="btn" style="font-size:.7rem;padding:.2rem .5rem" onclick="closePersonaModal();switchSection('personas', 'skills');openSkillDetailModal('${s.name}')">Inspect ↗</button>
    </div>
  `).join('');

  // Populate PGSP blocks from pgspPersonasData
  const personaIdMapping = {
    "pm": "A1", "domain_sme": "A2", "compliance_analyst": "A3", "ux_designer": "A4",
    "req_architect": "A5", "spec_adversary": "A6", "software_architect": "B1",
    "data_architect": "B2", "integration_engineer": "B3", "iam_engineer": "B4",
    "implementation_engineer": "C1", "test_engineer": "C2", "migration_engineer": "C3",
    "spec_conformance_judge": "D1", "security_red_team": "D2", "qa_adversarial_tester": "D3",
    "regulatory_conformance_verifier": "D4", "sre_resilience": "D5", "reconciliation_analyst": "D6",
    "observability_engineer": "E1", "documentation_curator": "E2", "release_manager": "E3",
    "persona_steward": "F1", "eval_engineer": "F2", "autonomy_governor": "F3", "token_economics_analyst": "F4"
  };

  const code = personaIdMapping[pId];
  const pgsp = (code && typeof pgspPersonasData !== 'undefined') ? pgspPersonasData[code] : null;

  if (pgsp) {
    document.getElementById('persContentProfile').innerHTML = formatMarkdownSimple(pgsp.p_profile);
    document.getElementById('persContentGoals').innerHTML = formatMarkdownSimple(pgsp.g_goals);
    document.getElementById('persContentSkills').innerHTML = formatMarkdownSimple(pgsp.s_skills);
    document.getElementById('persContentProtocols').innerHTML = formatMarkdownSimple(pgsp.p_protocols);
    document.getElementById('persContentDD').innerHTML = formatMarkdownSimple(pgsp.double_diamond);
  } else {
    const fallbackText = "Modern Agent Specification (P-G-S-P) authored in master catalog.";
    document.getElementById('persContentProfile').textContent = fallbackText;
    document.getElementById('persContentGoals').textContent = fallbackText;
    document.getElementById('persContentSkills').textContent = fallbackText;
    document.getElementById('persContentProtocols').textContent = fallbackText;
    document.getElementById('persContentDD').textContent = fallbackText;
  }

  switchPersonaTab('overview');
  document.getElementById('personaModal').classList.add('open');
}

function _unused_old_openPersonaModal(pId) {"""

html = html.replace(old_open_persona, new_open_persona, 1)

# 3. Enhance card rendering in renderSkillsCatalog so clicking card opens skill modal
old_card_build = "card.innerHTML = `\n      <div style=\"display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.3rem\">"
new_card_build = """card.style.cursor = 'pointer';
    card.onclick = () => openSkillDetailModal(s.id);
    card.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.3rem">"""

html = html.replace(old_card_build, new_card_build, 1)

# 4. Enhance card bottom with "View Double Diamond Spec ↗"
old_card_footer = '<span style="font-size:.68rem;color:#8E7AA8;font-weight:700">Phases:</span>'
new_card_footer = '<span style="font-size:.68rem;color:#8E7AA8;font-weight:700">Phases:</span>'
# add a button in card footer
old_resource_link = '<a href="${s.resource_ref}" target="_blank"'
new_resource_link = '<span style="color:var(--zip-lime);font-size:.72rem;font-weight:700;display:inline-flex;align-items:center;gap:.2rem;margin-right:.5rem">💎 DD Spec ↗</span><a href="${s.resource_ref}" target="_blank"'
html = html.replace(old_resource_link, new_resource_link, 1)

# 5. Add filterSkills support for 'authored'
old_filter_fn = "function filterSkills(type, val, btn) {"
new_filter_fn = """function filterSkills(type, val, btn) {
  activeSkillFilter = { type, val };
  document.querySelectorAll('#skillsFilterPills .btn').forEach(b => b.className = 'btn');
  if (btn) btn.className = 'btn btn-primary';
  renderSkillsCatalog();
}"""

# Insert js_functions right before renderSkillsCatalog
render_marker = "function renderSkillsCatalog() {"
html = html.replace(render_marker, js_functions + "\n\n" + render_marker, 1)

# Also update the filter check in renderSkillsCatalog for 'authored'
old_filter_check = "} else if (activeSkillFilter.type === 'mvp') {"
new_filter_check = """} else if (activeSkillFilter.type === 'authored') {
      if (!s.double_diamond_spec && !s.has_double_diamond) return;
    } else if (activeSkillFilter.type === 'mvp') {"""
html = html.replace(old_filter_check, new_filter_check, 1)

with open("architecture-unpack/presentation/factory-explorer.html", "w") as f:
    f.write(html)

print("Updated factory-explorer.html with interactive Double Diamond skill viewer and PGSP persona tabs.")
