import re, os, sys

SRC = "/Users/pcorreia/Documents/Customers/Zip/Zip - Agentic Factory/zip  architecture.pdf"
OUT = "/Users/pcorreia/Documents/Customers/Zip/Zip - Agentic Factory/architecture-unpack/_work/pages"

d = open(SRC, "rb").read()

# Find every JPEG (DCTDecode) stream by SOI/EOI markers inside stream...endstream
count = 0
pos = 0
while True:
    s = d.find(b"stream", pos)
    if s == -1:
        break
    # skip EOL after 'stream'
    i = s + 6
    if d[i:i+2] == b"\r\n":
        i += 2
    elif d[i:i+1] in (b"\n", b"\r"):
        i += 1
    e = d.find(b"endstream", i)
    if e == -1:
        break
    blob = d[i:e]
    # trim trailing EOL
    blob = blob.rstrip(b"\r\n")
    if blob[:2] == b"\xff\xd8" and blob[-2:] == b"\xff\xd9":
        count += 1
        path = os.path.join(OUT, "page%02d.jpg" % count)
        open(path, "wb").write(blob)
        print(path, len(blob))
    pos = e + 9

print("extracted", count)
