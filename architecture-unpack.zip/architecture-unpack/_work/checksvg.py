"""Bounds-check hand-authored inline SVG in the deck.

Cannot screenshot in this sandbox, so this is the next best thing: parse every
<svg>, read its viewBox, and confirm every rect/line/text/ellipse/path sits
inside it. Catches the classic hand-authored-SVG bug of drawing off-canvas.
"""
import re, sys

h = open("/Users/pcorreia/Documents/Customers/Zip/Zip - Agentic Factory/"
         "architecture-unpack/presentation/index.html").read()

svgs = re.findall(r'<svg[^>]*viewBox="([^"]+)"[^>]*>(.*?)</svg>', h, re.S)
print("SVGs found:", len(svgs))
problems = 0

for n, (vb, body) in enumerate(svgs, 1):
    x0, y0, w, h_ = [float(v) for v in vb.split()]
    X1, Y1 = x0 + w, y0 + h_
    label = re.search(r'aria-label="([^"]*)"', h[h.find(vb):h.find(vb)+300])
    print("\n--- SVG %d  viewBox %g %g %g %g ---" % (n, x0, y0, w, h_))
    pts = []

    for m in re.finditer(r'<rect[^>]*?x="([-\d.]+)"[^>]*?y="([-\d.]+)"[^>]*?'
                         r'width="([-\d.]+)"[^>]*?height="([-\d.]+)"', body):
        x, y, ww, hh = map(float, m.groups())
        pts.append(("rect", x, y)); pts.append(("rect", x + ww, y + hh))

    for m in re.finditer(r'<line[^>]*?x1="([-\d.]+)"[^>]*?y1="([-\d.]+)"[^>]*?'
                         r'x2="([-\d.]+)"[^>]*?y2="([-\d.]+)"', body):
        a, b, c, d = map(float, m.groups())
        pts.append(("line", a, b)); pts.append(("line", c, d))

    for m in re.finditer(r'<text[^>]*?x="([-\d.]+)"[^>]*?y="([-\d.]+)"', body):
        x, y = map(float, m.groups()); pts.append(("text", x, y))

    for m in re.finditer(r'<ellipse[^>]*?cx="([-\d.]+)"[^>]*?cy="([-\d.]+)"[^>]*?'
                         r'rx="([-\d.]+)"[^>]*?ry="([-\d.]+)"', body):
        cx, cy, rx, ry = map(float, m.groups())
        pts.append(("ellipse", cx - rx, cy - ry)); pts.append(("ellipse", cx + rx, cy + ry))

    # absolute M/L/V/H coords inside path d= attributes
    for m in re.finditer(r'<path[^>]*?\sd="([^"]+)"', body):
        d = m.group(1)
        for c in re.finditer(r'[ML]\s*([-\d.]+)[, ]\s*([-\d.]+)', d):
            pts.append(("path", float(c.group(1)), float(c.group(2))))

    kinds = {}
    for k, x, y in pts:
        kinds[k] = kinds.get(k, 0) + 1
        if not (x0 - 1 <= x <= X1 + 1) or not (y0 - 1 <= y <= Y1 + 1):
            print("   OUT OF BOUNDS  %-8s (%g, %g)" % (k, x, y))
            problems += 1
    print("   checked:", ", ".join("%s=%d" % kv for kv in sorted(kinds.items())))
    xs = [p[1] for p in pts]; ys = [p[2] for p in pts]
    if xs:
        print("   extent x %g..%g   y %g..%g" % (min(xs), max(xs), min(ys), max(ys)))

print("\n=== %s ===" % ("ALL SVG GEOMETRY IN BOUNDS" if problems == 0
                        else "%d OUT-OF-BOUNDS POINTS" % problems))
sys.exit(1 if problems else 0)
