import re

with open("architecture-unpack/presentation/factory-explorer.html") as f:
    html = f.read()

# 1. Skill Detail Modal HTML
skill_modal_html = """
<!-- Skill Detail & Double Diamond Modal -->
<div class="modal-backdrop" id="skillDetailModal" onclick="if(event.target===this)closeSkillDetailModal()">
  <div class="modal-box" style="max-width:920px;max-height:90vh;overflow-y:auto">
    <button class="modal-close" onclick="closeSkillDetailModal()">✕</button>
    <div style="display:flex;align-items:center;gap:.6rem;margin-bottom:.4rem;flex-wrap:wrap">
      <span class="badge-mini" id="modalSkillCategory" style="background:#1C0038;color:#C9A9E9;border:1px solid #5A258F">LENDING INVARIANTS</span>
      <span class="badge-mini" id="modalSkillProvider" style="background:rgba(168,85,247,0.15);color:#A855F7;border:1px solid #A855F7">ZIP PROVIDED</span>
      <span class="badge-mini" id="modalSkillStatus" style="background:rgba(0,212,255,0.12);color:#00D4FF;border:1px solid #00D4FF">READY (HAVE RESOURCE)</span>
      <span class="badge-mini" id="modalSkillRuntime" style="background:rgba(190,242,2,0.12);color:var(--zip-lime);border:1px solid var(--zip-lime)">UNIVERSAL / BOTH</span>
    </div>
    
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:1rem;flex-wrap:wrap">
      <div>
        <h2 id="modalSkillName" style="color:#FFF;font-size:1.45rem;font-weight:900;margin-top:.2rem">Loan Amortization Calculator</h2>
        <code id="modalSkillId" style="font-size:.78rem;color:var(--zip-lime);background:#0D001A;padding:.2rem .5rem;border-radius:4px;display:inline-block;margin-top:.3rem">loan_amortization_calculator</code>
      </div>
      <div id="modalSkillMVPBadge"></div>
    </div>

    <p id="modalSkillDesc" style="color:#D8CCE8;font-size:.88rem;line-height:1.5;margin:1rem 0;background:#140128;padding:.8rem 1.1rem;border-radius:8px;border-left:3px solid var(--zip-lime)"></p>

    <!-- Modal Tabs -->
    <div style="display:flex;gap:.5rem;border-bottom:1px solid #36155F;padding-bottom:.5rem;margin-bottom:1rem;flex-wrap:wrap">
      <button class="btn btn-primary" id="tabBtnSkillDD" onclick="switchSkillModalTab('dd')">💎 Double Diamond Synthesis</button>
      <button class="btn" id="tabBtnSkillInvariants" onclick="switchSkillModalTab('invariants')">📐 Invariants & Formulas</button>
      <button class="btn" id="tabBtnSkillCode" onclick="switchSkillModalTab('code')">💻 Implementation & Verifications</button>
      <button class="btn" id="tabBtnSkillRaw" onclick="switchSkillModalTab('raw')">📄 Raw SKILL.md</button>
    </div>

    <!-- Tab 1: Double Diamond -->
    <div id="skillTabContentDD" style="display:block">
      <div id="skillDDContainer" style="display:flex;flex-direction:column;gap:1rem;font-size:.84rem;line-height:1.55;color:#E0D5F2"></div>
    </div>

    <!-- Tab 2: Invariants -->
    <div id="skillTabContentInvariants" style="display:none">
      <div id="skillInvariantsContainer" style="display:flex;flex-direction:column;gap:.8rem;font-size:.84rem;line-height:1.55;color:#E0D5F2"></div>
    </div>

    <!-- Tab 3: Code & Verifications -->
    <div id="skillTabContentCode" style="display:none">
      <div id="skillCodeContainer" style="display:flex;flex-direction:column;gap:1rem"></div>
    </div>

    <!-- Tab 4: Raw SKILL.md -->
    <div id="skillTabContentRaw" style="display:none">
      <pre id="skillRawContent" style="background:#090014;border:1px solid #2B0C4F;border-radius:8px;padding:1rem;font-size:.78rem;color:#BEF202;overflow-x:auto;max-height:400px;font-family:var(--font-mono);line-height:1.4"></pre>
    </div>

    <div style="border-top:1px solid #2C0C52;margin-top:1.2rem;padding-top:.8rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.6rem">
      <div style="font-size:.75rem;color:#A89BC2" id="modalSkillPersonas"></div>
      <div style="font-size:.75rem;color:#A89BC2" id="modalSkillLocation"></div>
    </div>
  </div>
</div>
"""

# Insert Skill Detail Modal right after personaModal
persona_modal_end = '<!-- Artifact Detail Modal -->'
if persona_modal_end in html:
    html = html.replace(persona_modal_end, skill_modal_html + "\n" + persona_modal_end)
    print("Inserted Skill Detail Modal HTML.")
else:
    print("Could not find insertion point for Skill Detail Modal HTML.")

# 2. Enhanced Persona Modal with P-G-S-P Tabs
old_persona_modal_content = """    <h4 style="color:#FFF;font-size:.9rem;margin-bottom:.5rem">🛠️ Machine-Executable Skills &amp; Capabilities:</h4>
    <div id="modalPersSkillsList" style="display:flex;flex-direction:column;gap:.6rem;margin-bottom:1rem"></div>

    <div style="background:#14012A;padding:.8rem 1rem;border-radius:8px;border-left:3px solid var(--zip-iris)">
      <b style="color:var(--zip-lime);font-size:.82rem">Verbatim Prompting Angle (Zip Persona Catalogue):</b>
      <p id="modalPersPrompt" style="color:#E0D5F2;font-size:.8rem;font-style:italic;margin-top:.3rem;line-height:1.45"></p>
    </div>"""

new_persona_modal_content = """    <!-- Modern Agent Specification (P-G-S-P) Tabs -->
    <div style="display:flex;gap:.4rem;border-bottom:1px solid #36155F;padding-bottom:.5rem;margin-bottom:1rem;flex-wrap:wrap">
      <button class="btn btn-primary" id="btnPersTabOverview" onclick="switchPersonaTab('overview')">Overview &amp; Prompt</button>
      <button class="btn" id="btnPersTabProfile" onclick="switchPersonaTab('profile')">P — Persona Profile</button>
      <button class="btn" id="btnPersTabGoals" onclick="switchPersonaTab('goals')">G — Goals &amp; Invariants</button>
      <button class="btn" id="btnPersTabSkills" onclick="switchPersonaTab('skills')">S — Skills &amp; Substrates</button>
      <button class="btn" id="btnPersTabProtocols" onclick="switchPersonaTab('protocols')">P — Protocols &amp; Governance</button>
      <button class="btn" id="btnPersTabDD" onclick="switchPersonaTab('dd')">💎 Double Diamond Genesis</button>
    </div>

    <!-- Tab 1: Overview -->
    <div id="persTabOverview" style="display:block">
      <h4 style="color:#FFF;font-size:.9rem;margin-bottom:.5rem">🛠️ Machine-Executable Skills &amp; Capabilities:</h4>
      <div id="modalPersSkillsList" style="display:flex;flex-direction:column;gap:.6rem;margin-bottom:1rem"></div>

      <div style="background:#14012A;padding:.8rem 1rem;border-radius:8px;border-left:3px solid var(--zip-iris)">
        <b style="color:var(--zip-lime);font-size:.82rem">Verbatim Prompting Angle (Zip Persona Catalogue):</b>
        <p id="modalPersPrompt" style="color:#E0D5F2;font-size:.8rem;font-style:italic;margin-top:.3rem;line-height:1.45"></p>
      </div>
    </div>

    <!-- Tab 2: Persona Profile (P) -->
    <div id="persTabProfile" style="display:none;background:#100022;padding:1rem;border-radius:8px;border:1px solid #341258">
      <h4 style="color:var(--zip-lime);margin-top:0;font-size:.95rem">P — Persona Profile &amp; Cognitive Architecture</h4>
      <div id="persContentProfile" style="font-size:.84rem;line-height:1.55;color:#E0D5F2;white-space:pre-wrap;font-family:var(--font-main)"></div>
    </div>

    <!-- Tab 3: Goals & Invariants (G) -->
    <div id="persTabGoals" style="display:none;background:#100022;padding:1rem;border-radius:8px;border:1px solid #341258">
      <h4 style="color:var(--zip-lime);margin-top:0;font-size:.95rem">G — Strategic Goals &amp; Enforced Invariants</h4>
      <div id="persContentGoals" style="font-size:.84rem;line-height:1.55;color:#E0D5F2;white-space:pre-wrap;font-family:var(--font-main)"></div>
    </div>

    <!-- Tab 4: Skills & Substrates (S) -->
    <div id="persTabSkills" style="display:none;background:#100022;padding:1rem;border-radius:8px;border:1px solid #341258">
      <h4 style="color:var(--zip-lime);margin-top:0;font-size:.95rem">S — Bound Skills, Substrates &amp; Tools</h4>
      <div id="persContentSkills" style="font-size:.84rem;line-height:1.55;color:#E0D5F2;white-space:pre-wrap;font-family:var(--font-main)"></div>
    </div>

    <!-- Tab 5: Protocols & Governance (P) -->
    <div id="persTabProtocols" style="display:none;background:#100022;padding:1rem;border-radius:8px;border:1px solid #341258">
      <h4 style="color:var(--zip-lime);margin-top:0;font-size:.95rem">P — Adversarial Protocols &amp; Quality Gates</h4>
      <div id="persContentProtocols" style="font-size:.84rem;line-height:1.55;color:#E0D5F2;white-space:pre-wrap;font-family:var(--font-main)"></div>
    </div>

    <!-- Tab 6: Double Diamond Genesis -->
    <div id="persTabDD" style="display:none;background:#100022;padding:1rem;border-radius:8px;border:1px solid #341258">
      <h4 style="color:var(--zip-lime);margin-top:0;font-size:.95rem">💎 Double Diamond Persona Genesis (Discover, Define, Develop, Deliver)</h4>
      <div id="persContentDD" style="font-size:.84rem;line-height:1.55;color:#E0D5F2;white-space:pre-wrap;font-family:var(--font-main)"></div>
    </div>"""

if old_persona_modal_content in html:
    html = html.replace(old_persona_modal_content, new_persona_modal_content)
    print("Enhanced Persona Modal with PGSP tabs.")
else:
    print("Could not find old persona modal content to replace.")

# 3. Add Announcement Banner to the top of viewHome
home_announcement = """
    <!-- Announcement Banner: Double Diamond Skills & PGSP Personas -->
    <div style="background:linear-gradient(90deg, #2A084E 0%, #431078 50%, #1D0538 100%);border:1px solid var(--zip-lime);border-radius:10px;padding:1rem 1.4rem;margin-bottom:1.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;box-shadow:0 0 20px rgba(190,242,2,0.15)">
      <div style="display:flex;align-items:center;gap:.8rem">
        <span style="font-size:1.8rem">💎</span>
        <div>
          <div style="display:flex;align-items:center;gap:.5rem">
            <span style="color:#FFF;font-weight:800;font-size:1rem">NEW UPDATE: Double Diamond Skills &amp; Modern Agent Specifications (P-G-S-P)</span>
            <span class="badge-mini" style="background:#2E4C00;color:var(--zip-lime);border:1px solid var(--zip-lime);font-size:.65rem;font-weight:700">100% READY</span>
          </div>
          <p style="color:#D8CCE8;font-size:.8rem;margin-top:.2rem">All 23 unbuilt domain/governance skills authored via Double Diamond · All 26 agent personas specified in P-G-S-P format with zero placeholders.</p>
        </div>
      </div>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap">
        <button class="btn btn-primary" onclick="switchSection('personas', 'skills')">🧩 View Skills Catalog (56/56)</button>
        <button class="btn" onclick="switchSection('personas')" style="border-color:#FFF;color:#FFF">👥 View Personas (P-G-S-P)</button>
      </div>
    </div>
"""

home_insert_target = '<!-- 1. TRANSFORMATION METRICS CARDS -->'
if home_insert_target in html:
    html = html.replace(home_insert_target, home_announcement + "\n    " + home_insert_target)
    print("Injected Announcement Banner on Home view.")
else:
    print("Could not find insertion target for home announcement.")

with open("architecture-unpack/presentation/factory-explorer.html", "w") as f:
    f.write(html)

print("HTML updated with modals and banner.")
